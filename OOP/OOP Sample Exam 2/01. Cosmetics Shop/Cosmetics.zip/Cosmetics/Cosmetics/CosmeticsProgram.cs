﻿using System;

namespace Cosmetics
{
    using Engine;

    public class CosmeticsProgram
    {
        public static void Main()
        {
            CosmeticsEngine.Instance.Start();
        }
    }
}
