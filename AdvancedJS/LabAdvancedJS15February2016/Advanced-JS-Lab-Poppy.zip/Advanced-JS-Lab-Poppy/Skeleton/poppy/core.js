function pop(type, title, message) {
    var popup;
    switch (type) {
        // TODO: Implement various popup types
    }
	
	// generate view from view factory
    var view = createPopupView(popup);

    processPopup(view, popup);
}

function processPopup(domView, popup) {
	// TODO: Implement popup logic
}
