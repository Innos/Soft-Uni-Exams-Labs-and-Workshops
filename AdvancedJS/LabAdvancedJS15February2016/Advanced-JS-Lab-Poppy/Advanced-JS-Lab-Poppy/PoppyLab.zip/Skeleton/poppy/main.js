
poppy.pop('success', "Hello", "sup");
poppy.pop('info', "Super", "dawg");
poppy.pop('error', "Shibe", "wow");
poppy.pop('warning',"Callback", "Test", test);

function test(){
    console.log("Testing");
}

