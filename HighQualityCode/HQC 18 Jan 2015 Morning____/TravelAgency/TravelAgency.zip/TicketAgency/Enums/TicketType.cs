﻿namespace TicketAgency.Enums
{
    public enum TicketType
    {
        air,

        bus,

        train
    }
}
