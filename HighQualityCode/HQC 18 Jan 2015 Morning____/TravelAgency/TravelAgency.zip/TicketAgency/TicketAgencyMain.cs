﻿
namespace TicketAgency
{
    using TicketAgency.Core;

    public class TicketAgencyMain
    {
        public static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
