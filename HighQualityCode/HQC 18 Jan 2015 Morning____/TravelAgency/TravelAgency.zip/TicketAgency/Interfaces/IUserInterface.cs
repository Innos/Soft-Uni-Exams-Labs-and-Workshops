﻿namespace TicketAgency.Interfaces
{
    public interface IUserInterface
    {
        string ReadLine();

        void WriteLine(string message);
    }
}
