﻿namespace VehiclePark.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
