﻿namespace IssueManager.Model
{
    public enum IssuePriority
    {
        Showstopper = 4,

        High = 3,

        Medium = 2,

        Low = 1
    }
}
