﻿namespace TheatreManager.Interfaces
{
    public interface IAppender
    {
        void Write(string message);
    }
}
