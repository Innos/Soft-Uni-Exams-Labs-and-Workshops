﻿namespace Phonebook
{
    using Phonebook.Core;

    public class PhonebookMain
    {
        private static void Main()
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}