﻿namespace Phonebook.Interfaces
{
    public interface IUserInterface
    {
        void WriteLine(string message);

        string ReadLine();
    }
}
