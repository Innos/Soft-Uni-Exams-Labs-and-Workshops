﻿namespace Strategy.ValidationStrategies
{
    public interface IValidationStrategy
    {
        void Validate(string code);
    }
}
