﻿namespace RPG.Weapons
{
    public class Sword : Weapon
    {
        private const string SwordName = "Sword";

        public Sword()
        {
            this.Name = SwordName;
        }
    }
}
