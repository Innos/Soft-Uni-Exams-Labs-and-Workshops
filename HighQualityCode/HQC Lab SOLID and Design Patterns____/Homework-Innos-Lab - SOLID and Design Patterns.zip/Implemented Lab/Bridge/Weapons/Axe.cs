﻿namespace RPG.Weapons
{
    public class Axe : Weapon
    {
        private const string AxeName = "Axe";

        public Axe()
        {
            this.Name = AxeName;
        }
    }
}
